package com.App1.testCases;

import java.io.IOException;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.App1.pageObjects.AddCustomerPage;
import com.App1.pageObjects.LoginPage;

public class TC_AddCustomer_003 extends BaseClass{
	
@Test
public void addNewCustomer() throws InterruptedException, IOException {
	LoginPage lp=new LoginPage(driver);
	lp.setUserName(username);
	lp.setPassword(password);
	lp.clickSubmit();
	Thread.sleep(3000);
	
	
	AddCustomerPage addcust = new AddCustomerPage(driver);
	addcust.clickAddNewCustomer();
	
	addcust.custName("sanduni");
	logger.info("username is entered");
	addcust.custgender("female");	
	logger.info("gender is entered");
	addcust.custdob("10", "11", "1996");
	logger.info("DOB is entered");
	Thread.sleep(3000);
	addcust.custaddress("Srilanka");
	logger.info("Country name is entered");
	addcust.custcity("pannala");
	logger.info("city name is entered");
	addcust.custstate("AP");
	logger.info("state is entered");
	addcust.custpinno("23223789");
	logger.info("pin number is enteredd");
	addcust.custtelephoneno("0766473838");
	logger.info("phone number is entered");
	String email=randomstring()+"@gmail.com";

	addcust.custemailid(email);
	logger.info("email is entered");
	addcust.custpassword("abcdef");
	logger.info("password is entered");
	addcust.custsubmit();
	logger.info("submitted form");
	Thread.sleep(3000);
	boolean res= driver.getPageSource().contains("Customer Registered Successfully!!!");
	if(res==true) {
		Assert.assertTrue(true);
		logger.info("Test case passed");
	}
	
	else {
		logger.info("Testcase failed");
		captureScreen(driver,"addNewCustomer");
		Assert.assertTrue(false);
	
	}
}





}
