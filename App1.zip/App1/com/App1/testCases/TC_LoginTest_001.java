package com.App1.testCases;

import org.testng.annotations.Test;

public class TC_LoginTest_001 {
  @Test
  public void f() {
  }
}
